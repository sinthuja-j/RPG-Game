var searchData=
[
  ['oncollidedescription_207',['OnCollideDescription',['../classHealthPotion.html#a7d3c5604eb1c7889800600cdd5cd26f8',1,'HealthPotion']]],
  ['ondeath_208',['onDeath',['../classEnemy.html#a3c4bb920b677a8bf8f6315f1f6e2f90e',1,'Enemy']]]
];
