#include "Game.hpp"

/***
 * @brief Main Function
 * Runs the game
*/
int main(int argc, char* argv[]) {
    std::cout << "Main hello" << "\n";
    Game game;
    game.titleScreen();
    return 0;
}
